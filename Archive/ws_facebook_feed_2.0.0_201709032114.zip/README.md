# ws_facebook_feed
A fork of Typo3 extension ws_facebook_feed, v1.0

# Changelog
- The fork is not compatible with v1.0, anymore.
- Handle path to feed.json internally
- Remove obsolete fields in task and fe plugin

# Related
- https://extensions.typo3.org/extension/ws_facebook_feed/
- https://github.com/uschmelzer/ws_facebook_feed
